const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const productRoutes = require('./routes/products');
//config for view engine: ejs
const app = express();
app.set('view engine','ejs');
//midleware
app.use(bodyParser.urlencoded({extended: true}));
//connect to mongo
mongoose.connect('mongodb://localhost:27017/a1',{

}).then(()=>{
    console.log('Connect successfully');
}).catch(err=>{
    console.log('that bai:  ',err.message);
});
//using route for product management
app.use('/',productRoutes);
//listen
app.listen(3001,()=>{
    console.log('Serer is running at localhost:3001');
});