const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
//display all product
router.get('/admin',async (req,res)=>{
    try {
        const products = await Product.find();//get all
        res.render('admin',{products,product:null});//return data to layout
    } catch (error) {
        res.status(500).send(error.message);
    }
});
//add product
router.post('/add-product',async (req,res)=>{
    //get input from user
    const {id,name,price,description}=req.body;
    //create a new product with exist data
    const newProduct = new Product({id,name,price,description});
    try {
        await newProduct.save();//save data to mongo
        res.redirect('/admin');//chuyen huong sang admin
    } catch (error) {
        res.status(500).send(error);
    }
});
//get info of product for editing
router.get('/edit-product/:id',async (req,res)=>{
    try {
        //get product by id
        const product = await Product.findById(req.params.id);
        const products = await Product.find();//get all
        res.render('admin',{product,products});//return data to admin page
    } catch (error) {
        res.status(500).send(error);    
    }
});
//update product
router.post('/edit-product/:id',async (req,res)=>{
    //get input data from user
    const {name,price,description}=req.body;
    try {
        await Product.findByIdAndUpdate(req.params.id,{name,price,description});
        res.redirect('/admin');
    } catch (error) {
        res.status(500).send(error);
    }
});
//delete product
router.post('/delete-product/:id',async (req,res)=>{
    try {
        await Product.findByIdAndDelete(req.params.id);//delete product
        res.redirect('/admin');
    } catch (error) {
        res.status(500).send(error);
    }
});
module.exports = router;