import React from "react";
import { StyleSheet,Text,View,Button,TouchableOpacity } from "react-native";
export default class D3_1 extends React.Component{
    //1. ham khoi tao
    constructor(){
        super();
        //khai bao hang so phep tinh
        this.operations = ['+','-','*','/','DEL'];
        this.state = {
            resultText:"",//bien luu ket qua
            calculationText: "",//bien luu bieu thuc tinh toan
        };

    }
    //2. Cac ham tu dinh nghia
    //2.1 click vao button
    pressButton(text){
        if(text === "="){
            return this.calculationResult(this.state.resultText);//tinh toan ket qua
        }else if(text === "DEL"){ //xoa ky tu cuoi cung bang pop
            this.operate('DEL');//goi ham xu ly khi nhan DEL
        }
        else { //add text vao bieu thuc
            this.setState({
                resultText: this.state.resultText + text,
            });
        }
    }
    //2.1 ham tinh gia tri cua bieu thuc
    calculationResult(text){
        this.setState({
            calculationText: eval(text),
        });
    }
    //2.3 ham xu ly phep tinh
    operate(operation){
        switch(operation){
            case 'DEL':
                let text=this.state.resultText.split('');//pha vo chuoi
                text.pop();//xoa bo phan tu cuoi cung
                this.setState({
                    resultText: text.join(''),//join lai thanh chuoi va gan cho resultText
                });
                break;
            case '+':
            case '-':
            case '*':
            case '/':
                this.setState({
                    resultText: this.state.resultText+operation,//noi cac phep tinh
                });
                break;
        }
    }
    //giao dien
    render(){
        return(
            <View style={styles.container}>
                {/* view ket qua */}
                <View style={styles.result}>
                    <Text>{this.state.resultText}</Text>
                </View>
                {/* hien thi bieu thuc */}
                <View style={styles.calculation}>
                    <Text>{this.state.calculationText}</Text>
                </View>
                {/* view buttons */}
                <View style={styles.buttons}>
                    {/* view number1 */}
                    <View style={styles.number1}>
                        <TouchableOpacity style={styles.btn} key={1} onPress={()=>this.pressButton(1)}><Text>1</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={4} onPress={()=>this.pressButton(4)}><Text>4</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={7} onPress={()=>this.pressButton(7)}><Text>7</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={'.'} onPress={()=>this.pressButton('.')}><Text>.</Text></TouchableOpacity>
                    </View>
                    {/* view number2 */}
                    <View style={styles.number2}>
                        <TouchableOpacity style={styles.btn} key={2} onPress={()=>this.pressButton(2)}><Text>2</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={5} onPress={()=>this.pressButton(5)}><Text>5</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={8} onPress={()=>this.pressButton(8)}><Text>8</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={0} onPress={()=>this.pressButton(0)}><Text>0</Text></TouchableOpacity>
                    </View>
                    {/* view number3 */}
                    <View style={styles.number3}>
                        <TouchableOpacity style={styles.btn} key={3} onPress={()=>this.pressButton(3)}><Text>3</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={6} onPress={()=>this.pressButton(6)}><Text>6</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={9} onPress={()=>this.pressButton(9)}><Text>9</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={'='} onPress={()=>this.pressButton('=')}><Text>=</Text></TouchableOpacity>
                    </View>
                    {/* view phep tinh */}
                    <View style={styles.operations}>
                        <TouchableOpacity style={styles.btn} key={'+'} onPress={()=>this.pressButton('+')}><Text>+</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={'-'} onPress={()=>this.pressButton('-')}><Text>-</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={'*'} onPress={()=>this.pressButton('*')}><Text>*</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={'/'} onPress={()=>this.pressButton('/')}><Text>/</Text></TouchableOpacity>
                        <TouchableOpacity style={styles.btn} key={'DEL'} onPress={()=>this.pressButton('DEL')}><Text>DEL</Text></TouchableOpacity>
                    </View>
                </View>
            </View>
        );
    }
}
//CSS
const styles = StyleSheet.create({
    container: {
        flex:1, 
        flexDirection:'column',
    },
    result: {
        flex:1,
        // dinh dang chu
        justifyContent:'space-around',
        alignItems:'flex-end',
        backgroundColor:'green'
    },
    calculation:{
        flex:2,
        justifyContent:'space-around',
        alignItems:'flex-end',
        backgroundColor:'orange',
    },
    buttons: {
        flex:7,
        flexDirection:'row',
        backgroundColor:'#AAAA',
    },
    // chia tiep phan buttons
    numbers: {
        flex:3,
        flexDirection:'row',
        backgroundColor:'yellow',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    number1:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'#AAA1',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    number2:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'#AAA2',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    number3:{
        flex:1,
        flexDirection:'column',
        backgroundColor:'#AAA3',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    operations: {
        flex:1,
        flexDirection:'column',
        backgroundColor:'#AAA4',
        justifyContent:'space-around',
        alignItems:'stretch',
    },
    //dinh dang tung dong

    //dinh dang button
    btn:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    //dinh dang chu
    title:{
        textAlign:'center',
        fontSize: 30,
    },
});