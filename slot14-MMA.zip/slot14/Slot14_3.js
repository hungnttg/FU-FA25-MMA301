//Bottom Navigation
//npm i @react-navigation/native @react-navigation/bottom-tabs
//npm i @expo/vector-icons
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import {} from '@react-navigation/stack';
import {Ionicons} from '@expo/vector-icons';
import { ActivityIndicator, Text,View,FlatList } from 'react-native';
import { useState,useEffect } from 'react';
const Tab = createBottomTabNavigator();
function HomeScreen(){
    const [posts,setPosts]=useState([]);//luu tru bai viet
    const [loading, setLoading]=useState(true);//xu ly trang thai loading
    //doc du lieu
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/posts")
            .then(res=>res.json())//chuyen sang json
            .then(data =>{
                setPosts(data);//cap nhat trang thai
                setLoading(false);//da doc xong
            })
            .catch(error=>{
                console.error("Error loading posts: ",error);
                setLoading(false);
            });
            
    },[]);
    if(loading){
        return(
            <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
                <ActivityIndicator size="large" color="blue" />
                <Text>Dang tai du lieu...</Text>
            </View>
        );
    }
    return(
        <FlatList
            data={posts}
            keyExtractor={item=>item.id.toString()}
            renderItem={({item})=>(
                <View
                    style={{padding:10,borderBottomWidth:1,borderColor:"#ccc"}}
                >
                    <Text style={{fontWeight:'bold'}}>{item.title}</Text>
                    <Text>{item.body}</Text>
                </View>
            )}
        />
    );
}
function SettingsScreen(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Settings</Text>
        </View>
    );
}
function About(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>About</Text>
        </View>
    );
}
export default function Slot14_1(){
    return(
        
            <Tab.Navigator>
                <Tab.Screen
                    name="Home"
                    component={HomeScreen}
                    options={{
                        tabBarIcon: ({color,size})=>(
                            <Ionicons name="home" size={size} color={color}/>
                        )
                    }}
                />
                <Tab.Screen
                    name="Settings"
                    component={SettingsScreen}
                    options={{
                        tabBarIcon:({color,size}) =>(
                            <Ionicons name="settings" size={size} color={color} />
                        )
                    }}
                />
                <Tab.Screen
                    name="About"
                    component={About}
                    options={{
                        tabBarIcon:({color,size}) =>(
                            <Ionicons name="albums" size={size} color={color} />
                        )
                    }}
                />
            </Tab.Navigator>
       
    );
}
