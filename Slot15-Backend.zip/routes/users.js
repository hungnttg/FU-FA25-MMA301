//npm i express
const express = require('express');
const User = require('../model/User');
const router = express.Router();
//lay ve tat ca cac user
router.get('/',async (req,res)=>{
    try {
        res.json(await User.find());
    } catch (error) {
        res.status(500).json({message: error.message});
    }
});
//login
router.post('/login', async (req, res) => {
  try {
    const user = await User.findOne({ username: req.body.username });
    if (!user) {
      return res.status(401).json({ message: 'User không tồn tại' });
    }

    if (user.password !== req.body.password) {
      return res.status(401).json({ message: 'Sai mật khẩu' });
    }

    res.json({ token: user.username, role: user.role });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
});
module.exports = router;