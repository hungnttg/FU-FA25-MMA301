const express = require('express');
const mongoose = require('mongoose');
//npm i cors
const cors = require('cors');
//npm i body-parser
const bodyParser = require('body-parser');
const userRoutes = require('./routes/users');
const app = express();
//ket noi den mongo
mongoose.connect('mongodb://localhost:27017/AoCuoi',{
    useNewUrlParser:true,
    useUnifiedTopology: true
})
.then(()=>console.log('Da ket noi'))
.catch(err=>console.log(err));
//
app.use(cors());
app.use(bodyParser.json());
//
app.use('/api/users',userRoutes);
//them cai kha
//
app.listen(3001,()=>{
    console.log('server dang khoi dong o 3001');
});