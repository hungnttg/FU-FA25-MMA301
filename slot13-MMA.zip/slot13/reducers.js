//dinh nghia cac hanh dong
import { createReducer } from '@reduxjs/toolkit';
import { addItem, removeItem } from './actions';
const initialState = {items: []};
const cartReducer = createReducer(initialState,builder=>{
    builder
    .addCase(addItem,(state,action)=>{//dinh nghia: them SP vao gio hang
        //lay ve id san pham neu co
        const existingItemIndex = state.items.findIndex(item => item.id === action.payload.id);
        //kiem tra su ton tai cua san pham
        if(existingItemIndex !== -1){//ton tai id
            state.items[existingItemIndex].quantity++;
        } else {//khong ton tai
            state.items.push({...action.payload,quantity:1});
        }
    })
    .addCase(removeItem,(state,action)=>{
        //kiem tra xem co id khong
        const existingItemIndex = state.items.findIndex(item=>item.id === action.payload.id);
        if(existingItemIndex!== -1){//neu van co san pham
            state.items[existingItemIndex].quantity--; //giam so luong 
            //kiem tra neu so luong = 0 => xoa san pham luon
            if(state.items[existingItemIndex].quantity === 0){//neu soluong bang 0
                state.items.splice(existingItemIndex,1);//xoa san pham
            }
        }    
    });
});
export default cartReducer;