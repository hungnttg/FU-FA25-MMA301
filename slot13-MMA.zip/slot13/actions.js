//khai bao cac hanh dong
import { createAction } from '@reduxjs/toolkit';
export const addItem = createAction('cart/addItem');//them vao gio hang
export const removeItem = createAction('cart/removeItem');//xoa khoi gio hang