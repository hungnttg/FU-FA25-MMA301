//cai thu vien
//npm i @reduxjs/toolkit
//npm i react-redux
import React from "react";
import { View } from 'react-native';
import { Provider } from 'react-redux';
import store from "./store";
import ProductList from "./ProductList";
import Cart from "./Cart";
//tao list san pham (bai tap: doc du lieu tu API)
const products = [
    {id:1, name:'Product1'},
    {id:2, name:'Product2'},
    {id:3, name:'Product3'},
    {id:4, name:'Product4'},
];
const Slot13 = () =>{
    return(
        <Provider store={store}>
            <View>
                <ProductList products={products}/>
                <Cart/>
            </View>
        </Provider>
    );
}
export default Slot13;