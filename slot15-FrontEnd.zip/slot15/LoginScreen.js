import React,{useState} from "react";
import {View,Text,TextInput,Button,StyleSheet} from 'react-native';
import { loginUser } from "./api";
const LoginScreen = () =>{
    const [username,setUsername]=useState('');
    const [password,setPassword]=useState('');
    const [message,setMessage]=useState('');
    const [error,setError]=useState('');

    const handleLogin = async () =>{
        try {
            const response = await loginUser(username,password);
            if(response.role){
                setMessage("Dang nghap thanh cong");
                console.log(response);
            }
        } catch (error) {
            setError(error.message);
            console.error("Loi dang nhap: ",error);
        }
    };
    return(
        <View>
            <Text>Username:</Text>
            <TextInput
                value={username}
                onChangeText={setUsername}
                placeholder="Enter usename"
            />
            <Text>Passeord:</Text>
            <TextInput
                value={password}
                onChangeText={setPassword}
                placeholder="Enter password"
                secureTextEntry
            />
            {error ? <Text>{error}</Text> : <Text>{message}</Text>}
            <Button title="Login" onPress={handleLogin}/>
        </View>
    );
};
export default LoginScreen;