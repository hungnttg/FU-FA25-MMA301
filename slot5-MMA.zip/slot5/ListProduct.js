//import thu vien
import React from "react";
import { FlatList } from "react-native";
import Product from "./Product";
export default class ListProduct extends React.Component{
    //1. khai bao bien, state trong Constructor
    constructor(props){
        super(props);
        this.state={
            products: null, //khoi tao product
        };
        //khoi tao cac ham
        this.getProducts = this.getProducts.bind(this); //ham lay danh sach san pham
        this.renderItem = this.renderItem.bind(this);//ham ket xuat giao dien
    }
    //goi ham load du lieu (giong useEffect)
    componentDidMount(){
        this.getProducts();
    }
    //2. Dinh nghia cac ham
    //dinh nghia ham lay du lieu tu API
    async getProducts(){
        const url = 'https://hungnttg.github.io/shopgiay.json';
        let response = await fetch(url,{method:'GET'});//doc du lieu
        let responseJSON = await response.json();//chuyen sang JSON
        //cap nhat vao state
        this.setState({
            products: responseJSON.products,
        });
    }
    //dinh nghia ham ket xuat giao dien
    renderItem({item}){
        return(
            <Product dataProd={item} />
        );
    }
    //3.Layout
    render(){
        return(
            <FlatList
                data={this.state.products}
                renderItem={this.renderItem}
                numColumns={3}
                removeClippedSubviews
            />
        );
    };
}