import React from "react";
import { Text,View,Image,StyleSheet } from "react-native";
const SectionView = ({title,imageSource,description}) =>{
    return(
        <View style={styles.container}>
            <Text style={styles.title}>{title}</Text>
            <Image source={imageSource} style={styles.image}/>
            <Text style={styles.description}>{description}</Text>
        </View>
    );
};
const Slot9_2 = () =>{
    return(
        <View style={styles.container}>
            <SectionView
                title="Welcome"
                imageSource={{uri:'https://placehold.co/600x400'}}
                description="This is a welcom message"
            />
        </View>
    );
}
export default Slot9_2;
const styles = StyleSheet.create({
    container: {
        padding:20,
        backgroundColor: '#ffffff',
        borderRadius: 10,
        shadowColor: '#000',
        shadowOpacity: 0.25,
        elevation:5,
        shadowOffset: {width:0,height:2},
    },
    title :{
        fontSize:24,
        fontWeight:'bold',
        marginBottom:10,
    },
    image:{
        width:'100%',
        height:200,
        marginBottom: 10,
        borderRadius:5
    },
    description:{
        fontSize:15,
    }
});