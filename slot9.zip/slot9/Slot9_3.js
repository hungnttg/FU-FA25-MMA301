// validate
import React,{useState} from "react";
import { View,TextInput,Button,Text,StyleSheet } from "react-native";
const Slot9_3 = () =>{
    const [inputValue,setInputValue]=useState('');//kiem tra co nhap khong
    const [isInputValid,setIsInputValid]=useState(true);//kiem tra co hop le khong
    const handleBlur = () =>{
        setIsInputValid(inputValue.trim() !== '');
    };
    const handleSubmit = () => {
        setIsInputValid(inputValue.trim() !== '');
    };
    return(
        <View style={styles.container}>
            <TextInput
                style={[styles.input, !isInputValid && styles.invalid]}
                placeholder="Nhap ...."
                onChangeText={text=>{
                    setInputValue(text); 
                    setIsInputValid(true);
                }}
                onBlur={handleBlur}
            />
            {!isInputValid && <Text style={styles.errorText}>Vui long khong de trong</Text>}
            <Button title="Submit" onPress={handleSubmit}/>
        </View>
    );

}
const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent:'center',
        alignItems:'center',
    },
    input:{
        borderWidth:1,
        borderColor:'#ccc',
        padding:10,
        width:'80%',
        marginBottom: 10,
    },
    invalid:{
        borderColor:'red',
    },
    errorText:{
        color:'red',
        marginBottom:10,
    },
});
export default Slot9_3;