import React from "react";
import { Text,View,StyleSheet } from "react-native";
const SectionView = ({title, children, backgroundColor}) =>{
    return(
        <View style={[styles.container,{backgroundColor}]}>
            <Text style={styles.title}>{title}</Text>
        </View>
    );
};
const Slot9SectionView = () =>{
    return(
        <View style={styles.container}>
            <SectionView title="Header" backgroundColor="#ffcccc">
                <Text>Header content goes here</Text>
            </SectionView>
            <SectionView title="Content" backgroundColor="#1111">
                <Text>Content goes here</Text>
            </SectionView>
            <SectionView title="Footer" backgroundColor="#f0c7c7ff">
                <Text>Footer content goes here</Text>
            </SectionView>
        </View>
    );
};
export default Slot9SectionView;
const styles = StyleSheet.create({
    container:{
        flex:1,
        padding:20,
    },
    title :{
        fontSize:20,
        fontWeight:'bold',
        marginBottom:10,
    }
});