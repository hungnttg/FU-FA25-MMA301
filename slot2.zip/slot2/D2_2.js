import React,{useState} from "react";
import { Text,View,Button } from "react-native";
function D2_2(){
    //code
    const [count,setCount]=useState(0);
    //layout
    return(
        <View>
            <Text>So lan click {count}</Text>
            <Button onPress={()=>setCount(count+1)}>Click me</Button>
        </View>
    );
}
export default D2_2;