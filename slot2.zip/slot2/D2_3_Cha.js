import React from "react";
import { Text,View } from "react-native";
import D2_3_Con from "./D2_3_Con";
function D2_3_Cha(){
    const userName="Nguyen Van A";
    return(
        <View>
            <D2_3_Con name={userName} />
        </View>
    );
}
export default D2_3_Cha;