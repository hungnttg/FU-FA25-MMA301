import React,{useState} from "react";
import { Text,View,TextInput } from "react-native";
const D2_4_Con = ({onTextSubmit}) =>{
    //code
    const [ten,setTen]=useState(""); //thay doi gia tri khi nguoi dung nhap
    const handleSubmit = () =>{ //ham dua du lieu sang cha
        if(onTextSubmit){
            onTextSubmit(ten);//gui du lieu sang thanh phan cha
        }
    };
    //layout
    return(
        <View>
            <TextInput
                placeholder="moi ban nhap ho ten"
                editable
                onChangeText={(ten)=>setTen(ten)} //khi nguoi dung nhap
                onSubmitEditing={handleSubmit} //dua du lieu sang cha
            />
            <Text>Ban vua nhap: {ten}</Text>
        </View>
    );
}
export default D2_4_Con;