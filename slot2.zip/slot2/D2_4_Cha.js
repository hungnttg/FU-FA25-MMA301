import React,{useState} from "react";
import { Text,View,StyleSheet } from "react-native";
import D2_4_Con from "./D2_4_Con";
const D2_4_Cha = () =>{
    //code
    const [receivedText,setReceivedText]=useState("");
    //ham nhan gia tri tu Con
    const handleTextSubmit = (text) =>{
        setReceivedText(text);
    };
    //layout
    return(
        <View>
            <D2_4_Con onTextSubmit={handleTextSubmit}/>
            <Text>Du lieu nhan duoc la: {receivedText}</Text>
        </View>
    );
}
export default D2_4_Cha;