import React from "react";
import { Text,View } from "react-native";
function D2_3_Con({name}){
    return(
        <View>
            <Text>Xin chao {name}</Text>
        </View>
    );
}
export default D2_3_Con;