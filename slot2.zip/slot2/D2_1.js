//dem so lan click
import React from "react";
import { Text, View } from "react-native";
export default class D2_1 extends React.Component {
    //ham khoi tao
    constructor(props){
        super(props);
        this.state={
            //khai bao bien va khoi tao gia tri
            text: "click me",
            dem: 0,
        }
    };
    //dinh nghia ham updateText
    updateText(){
        //update Text moi khi click
        this.setState((preState)=>{
            return {
                dem: preState.dem + 1,
                text: 'Ban vua click lan thu ',
            }
        });
    }
    //giao dien
    render(){
        return(
            <View>
                <Text
                    // xu ly su kien
                    onPress={()=>this.updateText()}
                >
                    {/* goi bien */}
                    {this.state.text} : {this.state.dem}
                </Text>
            </View>
        );
    }
}