//npm i express
//npm i mysql2
//npm i cors
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const app = express();//tao doi tuong app
app.use(cors());//su dung cors, cho phep ket noi tu front end
//tao ket noi csdl
const conn = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database: "a1"
});
//thuc hien ket noi
conn.connect(err=>err);
//viet api
app.get('/data',(req,res)=>{
    conn.query('select * from mytable',(err,results)=>{
        if(err) throw err;
        res.json({products: results});
    });
});
//lang nghe
app.listen(3001,()=>{
    console.log("server dang chay o cong 3001");
});