import React,{useState} from "react";
import { Text,View,StyleSheet,TouchableOpacity } from "react-native";
export default function D4_1(){
    //code
    const [caculation,setCaculation]=useState('');
    const [result,setResult]=useState('');
    //ham pressButton
    const pressButton = (text) =>{
        if(text === "="){
            try {
                setResult(eval(caculation).toString());//tinh gia tri bieu thuc => luu vao Result
                setCaculation('');//reset lai calculation
            } catch (error) {
                setResult("Loi: "+error.message);
            }
        }
        else {//neu khong phai dau "bang =" thi noi text
            setCaculation(prev => prev + text);
        }
    };
    //ham xu ly khi nhan phim DEL
    const operate = (op) =>{
        if(op === 'DEL'){
            setCaculation(prev => prev.slice(0,-1));//cat ky tu cuoi cung
        }
        else {//neu khong phai DEL thi la noi chuoi
            setCaculation(prev => prev + op);
        }
    };
    //ham tao cac so bang vong lap: tra ve 1 ma tran so
    const renderNumberButtons = () =>{
        const nums = [[1,2,3],[4,5,6],[7,8,9],['.','0','=']];
        return nums.map((row,i)=>(
            <View key={i} style={styles.row}>
                {row.map((num)=>(
                    <TouchableOpacity key={num} style={styles.btn} 
                        onPress={()=>pressButton(num.toString())}>
                        <Text style={styles.txt}>{num}</Text>
                    </TouchableOpacity>
                ))}
            </View>
        ));
    };
    const renderOperatorButtons = () =>{
        const ops = ['+','-','*','/','DEL'];
        return ops.map((op)=>(
            <TouchableOpacity key={op} style={styles.btn} onPress={()=>operate(op)}>
                <Text style={styles.txt}>{op}</Text>
            </TouchableOpacity>
        ));
    };
    //layout
    return(
        <View style={styles.container}>
            <View style={styles.resultText}>
                <Text style={styles.txt}>{result}</Text>
            </View>
            {/* ---- */}
            <View style={styles.calculationText}>
                <Text style={styles.txt}>{caculation}</Text>
            </View>
            {/* ---- */}
            <View style={styles.buttons}>
                <View style={styles.numberButtons}>
                    {renderNumberButtons()}
                </View>
                <View style={styles.operationButtons}>
                    {renderOperatorButtons()}
                </View>
            </View>

        </View>
    );
}
const styles = StyleSheet.create({
    container: {
        flex:1, backgroundColor:'yellow'
    },
    resultText: {
        flex:1,
        backgroundColor:'green',
        justifyContent:'center',
        alignItems:'center'
    },
    calculationText: {
        flex:2,
        backgroundColor:'#AAA4',
        justifyContent:'center',
        alignItems:'center',
    },
    buttons: {
        flex:7,
        flexDirection:'row',
        backgroundColor:'pink',
    },
    numberButtons:{
        flex:3,
        backgroundColor:'#BB1',
        justifyContent:'space-around',
    },
    operationButtons:{
        flex:1,
        backgroundColor:'#CC1',
        justifyContent:'space-around',
    },
    row: {
        flexDirection:'row',
        justifyContent:'space-around',
    },
    btn: {
        flex:1,
        backgroundColor:'#DD1',
        justifyContent:'center',
        alignItems:'center',
        padding:20,
    },
    txt:{
        fontSize:30,
        fontWeight:'bold',
    },

});