//1. Import thu vien
import React from "react";
import {Text,View} from 'react-native';
//2. Dinh nghia class
class Demo1_1 extends React.Component{
//code
//layout
render(){
    return(
        <View>
            <Text>Xin chao cac ban den voi React Native</Text>
        </View>
    );
}
}
export default Demo1_1;