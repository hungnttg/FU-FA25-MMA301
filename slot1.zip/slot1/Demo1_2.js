//1. import thu vien
import React from "react";
import {Text,View} from 'react-native';
//2.Dinh nghia ham
const Demo1_2 = () =>{
//code
//layout
    return(
        <View>
            <Text>Day la cach dung Function</Text>
        </View>
    );
}
//3. export ham
export default Demo1_2;