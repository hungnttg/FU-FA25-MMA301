import React,{useState,useCallback,useEffect,memo} from "react";
import {Text,View,Button,StyleSheet} from "react-native";
//header
const Header = memo(({title}) => {
    return(
        <View style={styles.header}>
            <Text style={styles.headerText}>{title}</Text>
        </View>
    );
});
const Footer = memo(({year})=>{
    return(
        <View style={styles.footer}>
            <Text style={styles.footerText}>&copy; {year}</Text>
        </View>
    );
});
export default function App11(){
    const [count,setCount]=useState(0);
    const increment = useCallback(()=>{
        setCount((pre)=>pre+1)
    },[]);
    useEffect(()=>{
        console.log('Count: ',count);
    },[count]);
    return(
        <View style={styles.container}>
            <Header title="My App"/>
            <View style={styles.main}>
                <Text style={styles.counterText}>Count: {count}</Text>
                <Button title="Increment" onPress={increment}/>
            </View>
            <Footer year={new Date().getFullYear()}/>
        </View>
    );
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        justifyContent:'center',
        alignItems:'center',
        backgroundColor:'#fff'
    },
    header:{
        backgroundColor: 'lightblue',
        width:'100%',
        padding:10,
        alignItems:'center',
    },
    headerText:{
        fontSize:20,
        fontWeight:'bold',
    },
    main:{
        alignItems:'center',
        marginVertical: 20,
    },
    counterText: {
        fontSize:18,
        marginBottom: 10,
    },
    footer:{
        backgroundColor:'lightblue',
        width:'100%',
        padding: 10,
        alignItems:'center',
    },
     footerText:{
        fontSize:20,
        fontWeight:'bold',
    },
});