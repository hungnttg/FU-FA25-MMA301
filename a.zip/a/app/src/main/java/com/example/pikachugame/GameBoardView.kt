package com.example.pikachugame

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

class GameBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var gameManager: GameManager? = null
    private val soundManager = SoundManager(context)
    private val boardSize = 8
    private var cellSize = 0f
    private var boardOffsetX = 0f
    private var boardOffsetY = 0f
    
    private val gameBoard = Array(boardSize) { Array(boardSize) { TileType.EMPTY } }
    private val paint = Paint()
    private val tileColors = mapOf(
        TileType.RED to Color.parseColor("#FF6B6B"),
        TileType.BLUE to Color.parseColor("#4ECDC4"),
        TileType.GREEN to Color.parseColor("#45B7D1"),
        TileType.PURPLE to Color.parseColor("#96CEB4"),
        TileType.ORANGE to Color.parseColor("#FFEAA7"),
        TileType.YELLOW to Color.parseColor("#FFD700")
    )

    private var selectedTile: Pair<Int, Int>? = null
    private var firstTouchX = 0f
    private var firstTouchY = 0f

    // Animation properties
    private var swapAnimator: ValueAnimator? = null
    private var swapProgress = 0f
    private var swappingTiles: Pair<Pair<Int, Int>, Pair<Int, Int>>? = null
    
    // Particle effects
    private val particles = mutableListOf<Particle>()
    private var particleAnimator: ValueAnimator? = null
    
    // Match effects
    private val matchEffects = mutableListOf<MatchEffect>()
    private var matchAnimator: ValueAnimator? = null
    
    // Combo system
    private var comboCount = 0
    private var lastMatchTime = 0L
    private val comboTimeout = 2000L // 2 seconds
    
    // Combo text effects
    private val comboTexts = mutableListOf<ComboText>()
    private var comboTextAnimator: ValueAnimator? = null

    init {
        initializeBoard()
        setupAnimators()
    }

    private fun setupAnimators() {
        // Swap animation
        swapAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 300
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { animator ->
                swapProgress = animator.animatedValue as Float
                invalidate()
            }
        }

        // Particle animation
        particleAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                updateParticles()
                invalidate()
            }
        }

        // Match effect animation
        matchAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { animator ->
                updateMatchEffects(animator.animatedValue as Float)
                invalidate()
            }
        }
        
        // Combo text animation
        comboTextAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { animator ->
                updateComboTexts(animator.animatedValue as Float)
                invalidate()
            }
        }
    }

    fun setGameManager(manager: GameManager) {
        this.gameManager = manager
        manager.startGame()
    }

    private fun initializeBoard() {
        for (i in 0 until boardSize) {
            for (j in 0 until boardSize) {
                val types = TileType.values().filter { it != TileType.EMPTY }
                gameBoard[i][j] = types[Random.nextInt(types.size)]
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        
        val minDimension = min(w, h)
        cellSize = (minDimension * 0.9f) / boardSize
        boardOffsetX = (w - boardSize * cellSize) / 2
        boardOffsetY = (h - boardSize * cellSize) / 2
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawBoard(canvas)
        drawParticles(canvas)
        drawMatchEffects(canvas)
        drawComboTexts(canvas)
    }

    private fun drawBoard(canvas: Canvas) {
        for (i in 0 until boardSize) {
            for (j in 0 until boardSize) {
                val tile = gameBoard[i][j]
                if (tile != TileType.EMPTY) {
                    drawTile(canvas, i, j, tile)
                }
            }
        }
    }

    private fun drawTile(canvas: Canvas, row: Int, col: Int, tileType: TileType) {
        val x = boardOffsetX + col * cellSize
        val y = boardOffsetY + row * cellSize
        
        // Apply swap animation
        var drawX = x
        var drawY = y
        
        if (swappingTiles != null && swapProgress > 0f) {
            val (tile1, tile2) = swappingTiles!!
            if ((row == tile1.first && col == tile1.second) || 
                (row == tile2.first && col == tile2.second)) {
                
                val targetX = if (row == tile1.first && col == tile1.second) {
                    boardOffsetX + tile2.second * cellSize
                } else {
                    boardOffsetX + tile1.second * cellSize
                }
                
                val targetY = if (row == tile1.first && col == tile1.second) {
                    boardOffsetY + tile2.first * cellSize
                } else {
                    boardOffsetY + tile1.first * cellSize
                }
                
                drawX = x + (targetX - x) * swapProgress
                drawY = y + (targetY - y) * swapProgress
            }
        }
        
        val rect = RectF(drawX + 2, drawY + 2, drawX + cellSize - 2, drawY + cellSize - 2)

        // Draw tile background with shadow
        paint.color = Color.parseColor("#40000000")
        canvas.drawRoundRect(RectF(rect.left + 2, rect.top + 2, rect.right + 2, rect.bottom + 2), 8f, 8f, paint)
        
        paint.color = tileColors[tileType] ?: Color.GRAY
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(rect, 8f, 8f, paint)

        // Draw border
        paint.color = Color.WHITE
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        canvas.drawRoundRect(rect, 8f, 8f, paint)

        // Highlight selected tile
        if (selectedTile?.first == row && selectedTile?.second == col) {
            paint.color = Color.YELLOW
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f
            canvas.drawRoundRect(rect, 8f, 8f, paint)
        }
    }

    private fun drawParticles(canvas: Canvas) {
        paint.style = Paint.Style.FILL
        for (particle in particles) {
            paint.color = particle.color
            paint.alpha = (particle.alpha * 255).toInt()
            canvas.drawCircle(particle.x, particle.y, particle.size, paint)
        }
    }

    private fun drawMatchEffects(canvas: Canvas) {
        paint.style = Paint.Style.STROKE
        for (effect in matchEffects) {
            paint.color = effect.color
            paint.strokeWidth = 4f
            paint.alpha = (effect.alpha * 255).toInt()
            canvas.drawCircle(effect.x, effect.y, effect.radius, paint)
        }
    }
    
    private fun drawComboTexts(canvas: Canvas) {
        paint.style = Paint.Style.FILL
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 40f
        
        for (comboText in comboTexts) {
            paint.color = comboText.color
            paint.alpha = (comboText.alpha * 255).toInt()
            canvas.drawText(comboText.text, comboText.x, comboText.y, paint)
        }
    }

    private fun updateParticles() {
        particles.removeAll { particle ->
            particle.life -= 16f // 60fps
            particle.x += particle.vx
            particle.y += particle.vy
            particle.vy += 0.5f // gravity
            particle.alpha = particle.life / particle.maxLife
            particle.life <= 0
        }
    }

    private fun updateMatchEffects(progress: Float) {
        matchEffects.removeAll { effect ->
            effect.alpha = 1f - progress
            effect.radius = effect.baseRadius + progress * 50f
            progress >= 1f
        }
    }
    
    private fun updateComboTexts(progress: Float) {
        comboTexts.removeAll { comboText ->
            comboText.alpha = 1f - progress
            comboText.y -= 2f
            progress >= 1f
        }
    }

    private fun createParticles(x: Float, y: Float, color: Int) {
        repeat(10) {
            particles.add(Particle(
                x = x + Random.nextFloat() * 100f - 50f,
                y = y + Random.nextFloat() * 100f - 50f,
                vx = Random.nextFloat() * 10f - 5f,
                vy = Random.nextFloat() * -10f - 5f,
                color = color,
                size = Random.nextFloat() * 8f + 2f,
                life = 1000f,
                maxLife = 1000f
            ))
        }
    }

    private fun createMatchEffect(x: Float, y: Float, color: Int) {
        matchEffects.add(MatchEffect(x, y, color, 30f))
        matchAnimator?.start()
    }
    
    private fun createComboText(x: Float, y: Float, comboCount: Int) {
        val text = when {
            comboCount >= 5 -> "MEGA COMBO!"
            comboCount >= 3 -> "COMBO x$comboCount!"
            else -> "MATCH!"
        }
        
        val color = when {
            comboCount >= 5 -> Color.parseColor("#FFD700") // Gold
            comboCount >= 3 -> Color.parseColor("#FF6B6B") // Red
            else -> Color.parseColor("#4ECDC4") // Blue
        }
        
        comboTexts.add(ComboText(x, y, text, color))
        comboTextAnimator?.start()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val (row, col) = getTileFromTouch(event.x, event.y)
                if (row != -1 && col != -1) {
                    selectedTile = Pair(row, col)
                    firstTouchX = event.x
                    firstTouchY = event.y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val (row, col) = getTileFromTouch(event.x, event.y)
                if (selectedTile != null && row != -1 && col != -1) {
                    val selectedRow = selectedTile!!.first
                    val selectedCol = selectedTile!!.second
                    
                    // Check if adjacent
                    if (isAdjacent(selectedRow, selectedCol, row, col)) {
                        swapTiles(selectedRow, selectedCol, row, col)
                        selectedTile = null
                        return true
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                selectedTile = null
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun getTileFromTouch(x: Float, y: Float): Pair<Int, Int> {
        if (x < boardOffsetX || y < boardOffsetY) return Pair(-1, -1)
        
        val col = ((x - boardOffsetX) / cellSize).toInt()
        val row = ((y - boardOffsetY) / cellSize).toInt()
        
        return if (row in 0 until boardSize && col in 0 until boardSize) {
            Pair(row, col)
        } else {
            Pair(-1, -1)
        }
    }

    private fun isAdjacent(row1: Int, col1: Int, row2: Int, col2: Int): Boolean {
        return (abs(row1 - row2) == 1 && col1 == col2) || (abs(col1 - col2) == 1 && row1 == row2)
    }

    private fun swapTiles(row1: Int, col1: Int, row2: Int, col2: Int) {
        // Start swap animation
        swappingTiles = Pair(Pair(row1, col1), Pair(row2, col2))
        swapAnimator?.start()
        
        // Play swap sound and vibration
        soundManager.playSwapSound()
        soundManager.vibrateShort()
        
        // Swap tiles after animation
        swapAnimator?.addUpdateListener(object : ValueAnimator.AnimatorUpdateListener {
            override fun onAnimationUpdate(animation: ValueAnimator) {
                if (animation.animatedFraction >= 1f) {
                    performSwap(row1, col1, row2, col2)
                    swapAnimator?.removeUpdateListener(this)
                }
            }
        })
    }

    private fun performSwap(row1: Int, col1: Int, row2: Int, col2: Int) {
        val temp = gameBoard[row1][col1]
        gameBoard[row1][col1] = gameBoard[row2][col2]
        gameBoard[row2][col2] = temp

        // Check for matches after swap
        if (!checkAndRemoveMatches()) {
            // If no matches, swap back
            val temp2 = gameBoard[row1][col1]
            gameBoard[row1][col1] = gameBoard[row2][col2]
            gameBoard[row2][col2] = temp2
        } else {
            // No match, reset combo
            comboCount = 0
            fillEmptyTiles()
        }
        
        swappingTiles = null
        swapProgress = 0f
        invalidate()
    }

    private fun checkAndRemoveMatches(): Boolean {
        var hasMatches = false
        val matchedTiles = mutableSetOf<Pair<Int, Int>>()

        // Check horizontal matches
        for (row in 0 until boardSize) {
            for (col in 0 until boardSize - 2) {
                val tile1 = gameBoard[row][col]
                val tile2 = gameBoard[row][col + 1]
                val tile3 = gameBoard[row][col + 2]
                
                if (tile1 != TileType.EMPTY && tile1 == tile2 && tile2 == tile3) {
                    matchedTiles.add(Pair(row, col))
                    matchedTiles.add(Pair(row, col + 1))
                    matchedTiles.add(Pair(row, col + 2))
                    hasMatches = true
                }
            }
        }

        // Check vertical matches
        for (row in 0 until boardSize - 2) {
            for (col in 0 until boardSize) {
                val tile1 = gameBoard[row][col]
                val tile2 = gameBoard[row + 1][col]
                val tile3 = gameBoard[row + 2][col]
                
                if (tile1 != TileType.EMPTY && tile1 == tile2 && tile2 == tile3) {
                    matchedTiles.add(Pair(row, col))
                    matchedTiles.add(Pair(row + 1, col))
                    matchedTiles.add(Pair(row + 2, col))
                    hasMatches = true
                }
            }
        }

        // Create effects for matched tiles
        for ((row, col) in matchedTiles) {
            val tileType = gameBoard[row][col]
            val color = tileColors[tileType] ?: Color.GRAY
            val x = boardOffsetX + col * cellSize + cellSize / 2
            val y = boardOffsetY + row * cellSize + cellSize / 2
            
            createParticles(x, y, color)
            createMatchEffect(x, y, color)
        }

        // Play match sound and vibration
        if (matchedTiles.isNotEmpty()) {
            soundManager.playMatchSound()
            soundManager.vibrateLong()
            
            // Handle combo system
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastMatchTime < comboTimeout) {
                comboCount++
            } else {
                comboCount = 1
            }
            lastMatchTime = currentTime
            
            // Calculate score with combo multiplier
            val baseScore = matchedTiles.size * 100
            val comboMultiplier = 1 + (comboCount - 1) * 0.5f
            val finalScore = (baseScore * comboMultiplier).toInt()
            
            gameManager?.addScore(finalScore)
            
            // Create combo text effect
            val centerX = boardOffsetX + (boardSize * cellSize) / 2
            val centerY = boardOffsetY + (boardSize * cellSize) / 2
            createComboText(centerX, centerY, comboCount)
        }

        // Start particle animation if not already running
        if (particles.isNotEmpty() && particleAnimator?.isRunning != true) {
            particleAnimator?.start()
        }

        // Remove matched tiles
        for ((row, col) in matchedTiles) {
            gameBoard[row][col] = TileType.EMPTY
        }

        return hasMatches
    }

    private fun fillEmptyTiles() {
        val types = TileType.values().filter { it != TileType.EMPTY }
        
        for (col in 0 until boardSize) {
            for (row in boardSize - 1 downTo 0) {
                if (gameBoard[row][col] == TileType.EMPTY) {
                    gameBoard[row][col] = types[Random.nextInt(types.size)]
                }
            }
        }
    }

    data class Particle(
        var x: Float,
        var y: Float,
        var vx: Float,
        var vy: Float,
        val color: Int,
        val size: Float,
        var life: Float,
        val maxLife: Float,
        var alpha: Float = 1f
    )

    data class MatchEffect(
        val x: Float,
        val y: Float,
        val color: Int,
        val baseRadius: Float,
        var radius: Float = baseRadius,
        var alpha: Float = 1f
    )
    
    data class ComboText(
        val x: Float,
        var y: Float,
        val text: String,
        val color: Int,
        var alpha: Float = 1f
    )

    enum class TileType {
        RED, BLUE, GREEN, PURPLE, ORANGE, YELLOW, EMPTY
    }
} 