package com.example.pikachugame

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class SoundManager(private val context: Context) {
    
    private var soundPool: SoundPool? = null
    private var vibrator: Vibrator? = null
    
    // Sound IDs
    private var swapSoundId = 0
    private var matchSoundId = 0
    private var gameOverSoundId = 0
    
    // Settings
    var soundEnabled = true
    var vibrationEnabled = true
    
    init {
        initializeSoundPool()
        initializeVibrator()
    }
    
    private fun initializeSoundPool() {
        soundPool = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            SoundPool.Builder()
                .setMaxStreams(4)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .build()
        } else {
            @Suppress("DEPRECATION")
            SoundPool(4, android.media.AudioManager.STREAM_MUSIC, 0)
        }
        
        // Load sound effects (using system sounds for demo)
        // In a real app, you would load your own sound files
        swapSoundId = 1
        matchSoundId = 2
        gameOverSoundId = 3
    }
    
    private fun initializeVibrator() {
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }
    
    fun playSwapSound() {
        if (soundEnabled && soundPool != null) {
            soundPool?.play(swapSoundId, 0.5f, 0.5f, 1, 0, 1.0f)
        }
    }
    
    fun playMatchSound() {
        if (soundEnabled && soundPool != null) {
            soundPool?.play(matchSoundId, 0.8f, 0.8f, 1, 0, 1.2f)
        }
    }
    
    fun playGameOverSound() {
        if (soundEnabled && soundPool != null) {
            soundPool?.play(gameOverSoundId, 1.0f, 1.0f, 1, 0, 0.8f)
        }
    }
    
    fun vibrateShort() {
        if (vibrationEnabled && vibrator != null && vibrator!!.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(50)
            }
        }
    }
    
    fun vibrateLong() {
        if (vibrationEnabled && vibrator != null && vibrator!!.hasVibrator()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(200)
            }
        }
    }
    
    fun release() {
        soundPool?.release()
        soundPool = null
    }
} 