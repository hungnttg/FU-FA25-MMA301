package com.example.pikachugame

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.example.pikachugame.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var gameManager: GameManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupGame()
        setupUI()
    }

    private fun setupGame() {
        gameManager = GameManager()
        gameManager.setGameListener(object : GameManager.GameListener {
            override fun onScoreChanged(score: Int) {
                binding.scoreText.text = getString(R.string.score, score)
            }

            override fun onLevelChanged(level: Int) {
                binding.levelText.text = getString(R.string.level, level)
            }

            override fun onTimeChanged(time: Int) {
                binding.timeText.text = getString(R.string.time, time)
            }
            
            override fun onTargetScoreChanged(targetScore: Int) {
                binding.targetScoreText.text = getString(R.string.target_score, targetScore)
            }

            override fun onGameOver(score: Int) {
                showGameOverDialog(score)
            }

            override fun onLevelComplete(level: Int, score: Int, targetScore: Int) {
                showLevelCompleteDialog(level, score, targetScore)
            }
        })

        binding.gameBoard.setGameManager(gameManager)
    }

    private fun setupUI() {
        binding.pauseButton.setOnClickListener {
            if (gameManager.isPaused()) {
                gameManager.resumeGame()
                binding.pauseButton.text = getString(R.string.pause)
            } else {
                gameManager.pauseGame()
                binding.pauseButton.text = getString(R.string.resume)
            }
        }

        binding.restartButton.setOnClickListener {
            gameManager.restartGame()
            binding.pauseButton.text = getString(R.string.pause)
        }

        binding.menuButton.setOnClickListener {
            showLevelSelectionDialog()
        }

        // Game over dialog buttons
        binding.playAgainButton.setOnClickListener {
            hideGameOverDialog()
            gameManager.restartGame()
            binding.pauseButton.text = getString(R.string.pause)
        }

        binding.exitButton.setOnClickListener {
            finish()
        }
    }

    private fun showGameOverDialog(score: Int) {
        binding.finalScoreText.text = getString(R.string.score, score)
        binding.gameOverDialog.visibility = View.VISIBLE
    }

    private fun hideGameOverDialog() {
        binding.gameOverDialog.visibility = View.GONE
    }

    private fun showLevelCompleteDialog(level: Int, score: Int, targetScore: Int) {
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.level_complete_title, level))
            .setMessage(getString(R.string.level_complete_message, score, targetScore))
            .setPositiveButton(getString(R.string.next_level)) { _, _ ->
                gameManager.nextLevel()
            }
            .setNegativeButton(getString(R.string.retry_level)) { _, _ ->
                gameManager.restartGame()
            }
            .setCancelable(false)
            .create()
        
        dialog.show()
    }

    private fun showLevelSelectionDialog() {
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.select_level))
            .setMessage("Chọn level từ 1-200")
            .setPositiveButton("OK") { _, _ ->
                // For now, just show a simple level picker
                showSimpleLevelPicker()
            }
            .setNegativeButton("Hủy", null)
            .create()
        
        dialog.show()
    }
    
    private fun showSimpleLevelPicker() {
        val levels = (1..200).toList()
        val levelNames = levels.map { "Level $it" }.toTypedArray()
        
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Chọn Level")
            .setItems(levelNames) { _, which ->
                val selectedLevel = which + 1
                gameManager.setLevel(selectedLevel)
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    override fun onPause() {
        super.onPause()
        gameManager.pauseGame()
    }

    override fun onResume() {
        super.onResume()
        if (!gameManager.isGameOver()) {
            gameManager.resumeGame()
        }
    }
} 