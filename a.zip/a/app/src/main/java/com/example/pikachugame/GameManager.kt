package com.example.pikachugame

import android.os.Handler
import android.os.Looper
import java.util.*

class GameManager {
    private var score = 0
    private var currentLevel = 1
    private var timeLeft = 60
    private var targetScore = 500
    private var isPaused = false
    private var isGameOver = false
    private var gameListener: GameListener? = null
    private val handler = Handler(Looper.getMainLooper())
    private val levelManager = LevelManager()
    private var highestCompletedLevel = 0
    private val timerRunnable = object : Runnable {
        override fun run() {
            if (!isPaused && !isGameOver && timeLeft > 0) {
                timeLeft--
                gameListener?.onTimeChanged(timeLeft)
                if (timeLeft <= 0) {
                    endGame()
                } else {
                    handler.postDelayed(this, 1000)
                }
            }
        }
    }

    fun setGameListener(listener: GameListener) {
        this.gameListener = listener
    }

    fun startGame() {
        startLevel(currentLevel)
    }
    
    fun startLevel(levelNumber: Int) {
        val level = levelManager.getLevel(levelNumber)
        if (level != null) {
            isGameOver = false
            isPaused = false
            score = 0
            currentLevel = levelNumber
            timeLeft = level.timeLimit
            targetScore = level.targetScore
            
            gameListener?.onScoreChanged(score)
            gameListener?.onLevelChanged(currentLevel)
            gameListener?.onTimeChanged(timeLeft)
            gameListener?.onTargetScoreChanged(targetScore)
            startTimer()
        }
    }

    fun pauseGame() {
        isPaused = true
        handler.removeCallbacks(timerRunnable)
    }

    fun resumeGame() {
        isPaused = false
        if (!isGameOver && timeLeft > 0) {
            startTimer()
        }
    }

    fun restartGame() {
        handler.removeCallbacks(timerRunnable)
        startLevel(currentLevel)
    }

    fun nextLevel() {
        if (currentLevel < levelManager.getTotalLevels()) {
            currentLevel++
            startLevel(currentLevel)
        }
    }
    
    fun previousLevel() {
        if (currentLevel > 1) {
            currentLevel--
            startLevel(currentLevel)
        }
    }
    
    fun setLevel(levelNumber: Int) {
        if (levelNumber in 1..levelManager.getTotalLevels()) {
            currentLevel = levelNumber
            startLevel(currentLevel)
        }
    }

    fun addScore(points: Int) {
        score += points
        gameListener?.onScoreChanged(score)
    }

    fun isPaused(): Boolean = isPaused

    fun isGameOver(): Boolean = isGameOver

    private fun startTimer() {
        handler.postDelayed(timerRunnable, 1000)
    }

    private fun endGame() {
        isGameOver = true
        handler.removeCallbacks(timerRunnable)
        
        // Check if level completed
        if (score >= targetScore) {
            if (currentLevel > highestCompletedLevel) {
                highestCompletedLevel = currentLevel
            }
            gameListener?.onLevelComplete(currentLevel, score, targetScore)
        } else {
            gameListener?.onGameOver(score)
        }
    }

    fun getCurrentLevel(): Int = currentLevel

    fun getCurrentScore(): Int = score
    
    fun getTargetScore(): Int = targetScore

    fun getTimeLeft(): Int = timeLeft
    
    fun getLevelManager(): LevelManager = levelManager
    
    fun getHighestCompletedLevel(): Int = highestCompletedLevel

    interface GameListener {
        fun onScoreChanged(score: Int)
        fun onLevelChanged(level: Int)
        fun onTimeChanged(time: Int)
        fun onTargetScoreChanged(targetScore: Int)
        fun onGameOver(score: Int)
        fun onLevelComplete(level: Int, score: Int, targetScore: Int)
    }
} 