package com.example.pikachugame

import kotlin.random.Random

class LevelManager {
    
    data class Level(
        val levelNumber: Int,
        val targetScore: Int,
        val timeLimit: Int,
        val specialTiles: List<SpecialTile> = emptyList(),
        val boardSize: Int = 8,
        val description: String = ""
    )
    
    data class SpecialTile(
        val row: Int,
        val col: Int,
        val type: SpecialTileType
    )
    
    enum class SpecialTileType {
        BOMB,           // Nổ 3x3
        ROW_CLEAR,      // Xóa toàn bộ hàng
        COL_CLEAR,      // Xóa toàn bộ cột
        COLOR_BOMB,     // Xóa tất cả viên đá cùng màu
        CROSS_BOMB,     // Nổ hình chữ thập
        DIAMOND_BOMB,   // Nổ hình kim cương
        STAR_BOMB,      // Nổ hình ngôi sao
        RAINBOW_BOMB    // Nổ tất cả màu
    }
    
    private val levels = mutableListOf<Level>()
    
    init {
        generateLevels()
    }
    
    private fun generateLevels() {
        // Level 1-10: Tutorial và cơ bản
        for (i in 1..10) {
            levels.add(Level(
                levelNumber = i,
                targetScore = i * 500,
                timeLimit = 60,
                description = "Đạt $${i * 500} điểm trong 60 giây"
            ))
        }
        
        // Level 11-20: Tăng độ khó
        for (i in 11..20) {
            levels.add(Level(
                levelNumber = i,
                targetScore = 5000 + (i - 10) * 800,
                timeLimit = 55,
                description = "Đạt $${5000 + (i - 10) * 800} điểm trong 55 giây"
            ))
        }
        
        // Level 21-30: Thêm thời gian áp lực
        for (i in 21..30) {
            levels.add(Level(
                levelNumber = i,
                targetScore = 13000 + (i - 20) * 1000,
                timeLimit = 50,
                description = "Đạt $${13000 + (i - 20) * 1000} điểm trong 50 giây"
            ))
        }
        
        // Level 31-40: Thêm special tiles
        for (i in 31..40) {
            val specialTiles = if (i % 3 == 0) {
                listOf(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
            } else {
                emptyList()
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 23000 + (i - 30) * 1200,
                timeLimit = 45,
                specialTiles = specialTiles,
                description = "Đạt $${23000 + (i - 30) * 1200} điểm trong 45 giây"
            ))
        }
        
        // Level 41-50: Tăng special tiles
        for (i in 41..50) {
            val specialTiles = mutableListOf<SpecialTile>()
            if (i % 2 == 0) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
            }
            if (i % 3 == 0) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 35000 + (i - 40) * 1500,
                timeLimit = 40,
                specialTiles = specialTiles,
                description = "Đạt $${35000 + (i - 40) * 1500} điểm trong 40 giây"
            ))
        }
        
        // Level 51-60: Thêm column clear
        for (i in 51..60) {
            val specialTiles = mutableListOf<SpecialTile>()
            specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
            if (i % 2 == 0) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COL_CLEAR))
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 50000 + (i - 50) * 2000,
                timeLimit = 35,
                specialTiles = specialTiles,
                description = "Đạt $${50000 + (i - 50) * 2000} điểm trong 35 giây"
            ))
        }
        
        // Level 61-70: Thêm color bomb
        for (i in 61..70) {
            val specialTiles = mutableListOf<SpecialTile>()
            specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
            specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
            if (i % 3 == 0) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COLOR_BOMB))
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 70000 + (i - 60) * 2500,
                timeLimit = 30,
                specialTiles = specialTiles,
                description = "Đạt $${70000 + (i - 60) * 2500} điểm trong 30 giây"
            ))
        }
        
        // Level 71-80: Boss levels
        for (i in 71..80) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(2) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
            }
            specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
            specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COL_CLEAR))
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 95000 + (i - 70) * 3000,
                timeLimit = 25,
                specialTiles = specialTiles,
                description = "BOSS LEVEL: Đạt $${95000 + (i - 70) * 3000} điểm trong 25 giây"
            ))
        }
        
        // Level 81-90: Extreme levels
        for (i in 81..90) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(3) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
            }
            repeat(2) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
            }
            specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COLOR_BOMB))
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 125000 + (i - 80) * 4000,
                timeLimit = 20,
                specialTiles = specialTiles,
                description = "EXTREME: Đạt $${125000 + (i - 80) * 4000} điểm trong 20 giây"
            ))
        }
        
        // Level 91-99: Legendary levels
        for (i in 91..99) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(4) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
            }
            repeat(3) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
            }
            repeat(2) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COLOR_BOMB))
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 165000 + (i - 90) * 5000,
                timeLimit = 15,
                specialTiles = specialTiles,
                description = "LEGENDARY: Đạt $${165000 + (i - 90) * 5000} điểm trong 15 giây"
            ))
        }
        
        // Level 100: Final Boss
        levels.add(Level(
            levelNumber = 100,
            targetScore = 500000,
            timeLimit = 10,
            specialTiles = listOf(
                SpecialTile(0, 0, SpecialTileType.BOMB),
                SpecialTile(0, 7, SpecialTileType.BOMB),
                SpecialTile(7, 0, SpecialTileType.BOMB),
                SpecialTile(7, 7, SpecialTileType.BOMB),
                SpecialTile(3, 3, SpecialTileType.ROW_CLEAR),
                SpecialTile(4, 4, SpecialTileType.COL_CLEAR),
                SpecialTile(1, 1, SpecialTileType.COLOR_BOMB),
                SpecialTile(6, 6, SpecialTileType.COLOR_BOMB)
            ),
            description = "FINAL BOSS: Đạt 500,000 điểm trong 10 giây!"
        ))
        
        // Level 101-110: Ultra Basic
        for (i in 101..110) {
            levels.add(Level(
                levelNumber = i,
                targetScore = 600000 + (i - 100) * 10000,
                timeLimit = 8,
                description = "ULTRA: Đạt $${600000 + (i - 100) * 10000} điểm trong 8 giây"
            ))
        }
        
        // Level 111-120: Speed Challenge
        for (i in 111..120) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(3) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 700000 + (i - 110) * 15000,
                timeLimit = 7,
                specialTiles = specialTiles,
                description = "SPEED: Đạt $${700000 + (i - 110) * 15000} điểm trong 7 giây"
            ))
        }
        
        // Level 121-130: Precision Master
        for (i in 121..130) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(4) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 850000 + (i - 120) * 20000,
                timeLimit = 6,
                specialTiles = specialTiles,
                description = "PRECISION: Đạt $${850000 + (i - 120) * 20000} điểm trong 6 giây"
            ))
        }
        
        // Level 131-140: Column Master
        for (i in 131..140) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(4) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COL_CLEAR))
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 1050000 + (i - 130) * 25000,
                timeLimit = 5,
                specialTiles = specialTiles,
                description = "COLUMN: Đạt $${1050000 + (i - 130) * 25000} điểm trong 5 giây"
            ))
        }
        
        // Level 141-150: Color Master
        for (i in 141..150) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(5) {
                specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COLOR_BOMB))
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 1300000 + (i - 140) * 30000,
                timeLimit = 4,
                specialTiles = specialTiles,
                description = "COLOR: Đạt $${1300000 + (i - 140) * 30000} điểm trong 4 giây"
            ))
        }
        
        // Level 151-160: Chaos Mode
        for (i in 151..160) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(6) {
                when (Random.nextInt(8)) {
                    0 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
                    1 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
                    2 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COL_CLEAR))
                    3 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COLOR_BOMB))
                    4 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.CROSS_BOMB))
                    5 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.DIAMOND_BOMB))
                    6 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.STAR_BOMB))
                    7 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.RAINBOW_BOMB))
                }
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 1600000 + (i - 150) * 35000,
                timeLimit = 3,
                specialTiles = specialTiles,
                description = "CHAOS: Đạt $${1600000 + (i - 150) * 35000} điểm trong 3 giây"
            ))
        }
        
        // Level 161-170: Insane Mode
        for (i in 161..170) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(8) {
                when (Random.nextInt(8)) {
                    0 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
                    1 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
                    2 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COL_CLEAR))
                    3 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COLOR_BOMB))
                    4 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.CROSS_BOMB))
                    5 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.DIAMOND_BOMB))
                    6 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.STAR_BOMB))
                    7 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.RAINBOW_BOMB))
                }
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 1950000 + (i - 160) * 40000,
                timeLimit = 2,
                specialTiles = specialTiles,
                description = "INSANE: Đạt $${1950000 + (i - 160) * 40000} điểm trong 2 giây"
            ))
        }
        
        // Level 171-180: Impossible Mode
        for (i in 171..180) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(10) {
                when (Random.nextInt(8)) {
                    0 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
                    1 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
                    2 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COL_CLEAR))
                    3 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COLOR_BOMB))
                    4 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.CROSS_BOMB))
                    5 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.DIAMOND_BOMB))
                    6 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.STAR_BOMB))
                    7 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.RAINBOW_BOMB))
                }
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 2350000 + (i - 170) * 45000,
                timeLimit = 1,
                specialTiles = specialTiles,
                description = "IMPOSSIBLE: Đạt $${2350000 + (i - 170) * 45000} điểm trong 1 giây"
            ))
        }
        
        // Level 181-190: God Mode
        for (i in 181..190) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(12) {
                when (Random.nextInt(8)) {
                    0 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
                    1 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
                    2 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COL_CLEAR))
                    3 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COLOR_BOMB))
                    4 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.CROSS_BOMB))
                    5 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.DIAMOND_BOMB))
                    6 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.STAR_BOMB))
                    7 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.RAINBOW_BOMB))
                }
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 2800000 + (i - 180) * 50000,
                timeLimit = 1,
                specialTiles = specialTiles,
                description = "GOD: Đạt $${2800000 + (i - 180) * 50000} điểm trong 1 giây"
            ))
        }
        
        // Level 191-199: Ultimate Challenge
        for (i in 191..199) {
            val specialTiles = mutableListOf<SpecialTile>()
            repeat(15) {
                when (Random.nextInt(8)) {
                    0 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.BOMB))
                    1 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.ROW_CLEAR))
                    2 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COL_CLEAR))
                    3 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.COLOR_BOMB))
                    4 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.CROSS_BOMB))
                    5 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.DIAMOND_BOMB))
                    6 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.STAR_BOMB))
                    7 -> specialTiles.add(SpecialTile(Random.nextInt(8), Random.nextInt(8), SpecialTileType.RAINBOW_BOMB))
                }
            }
            
            levels.add(Level(
                levelNumber = i,
                targetScore = 3300000 + (i - 190) * 60000,
                timeLimit = 1,
                specialTiles = specialTiles,
                description = "ULTIMATE: Đạt $${3300000 + (i - 190) * 60000} điểm trong 1 giây"
            ))
        }
        
        // Level 200: Ultimate Final Boss
        levels.add(Level(
            levelNumber = 200,
            targetScore = 10000000,
            timeLimit = 1,
            specialTiles = listOf(
                // Corner bombs
                SpecialTile(0, 0, SpecialTileType.BOMB),
                SpecialTile(0, 7, SpecialTileType.BOMB),
                SpecialTile(7, 0, SpecialTileType.BOMB),
                SpecialTile(7, 7, SpecialTileType.BOMB),
                // Center bombs
                SpecialTile(3, 3, SpecialTileType.BOMB),
                SpecialTile(3, 4, SpecialTileType.BOMB),
                SpecialTile(4, 3, SpecialTileType.BOMB),
                SpecialTile(4, 4, SpecialTileType.BOMB),
                // Row clears
                SpecialTile(1, 1, SpecialTileType.ROW_CLEAR),
                SpecialTile(1, 6, SpecialTileType.ROW_CLEAR),
                SpecialTile(6, 1, SpecialTileType.ROW_CLEAR),
                SpecialTile(6, 6, SpecialTileType.ROW_CLEAR),
                // Column clears
                SpecialTile(2, 2, SpecialTileType.COL_CLEAR),
                SpecialTile(2, 5, SpecialTileType.COL_CLEAR),
                SpecialTile(5, 2, SpecialTileType.COL_CLEAR),
                SpecialTile(5, 5, SpecialTileType.COL_CLEAR),
                // Color bombs
                SpecialTile(0, 3, SpecialTileType.COLOR_BOMB),
                SpecialTile(0, 4, SpecialTileType.COLOR_BOMB),
                SpecialTile(7, 3, SpecialTileType.COLOR_BOMB),
                SpecialTile(7, 4, SpecialTileType.COLOR_BOMB)
            ),
            description = "ULTIMATE FINAL BOSS: Đạt 10,000,000 điểm trong 1 giây!"
        ))
    }
    
    fun getLevel(levelNumber: Int): Level? {
        return levels.find { it.levelNumber == levelNumber }
    }
    
    fun getTotalLevels(): Int = levels.size
    
    fun getLevels(): List<Level> = levels.toList()
    
    fun isLevelUnlocked(levelNumber: Int, highestCompletedLevel: Int): Boolean {
        return levelNumber <= highestCompletedLevel + 1
    }
    
    fun getLevelProgress(currentLevel: Int): Float {
        return (currentLevel - 1) / 200f
    }
    
    fun getLevelReward(levelNumber: Int): Int {
        return when {
            levelNumber <= 10 -> 100
            levelNumber <= 30 -> 200
            levelNumber <= 50 -> 300
            levelNumber <= 70 -> 400
            levelNumber <= 90 -> 500
            levelNumber <= 99 -> 1000
            levelNumber <= 110 -> 2000
            levelNumber <= 130 -> 3000
            levelNumber <= 150 -> 4000
            levelNumber <= 170 -> 5000
            levelNumber <= 190 -> 10000
            levelNumber <= 199 -> 20000
            else -> 100000 // Level 200
        }
    }
    
    fun getLevelStars(score: Int, targetScore: Int): Int {
        return when {
            score >= targetScore * 2 -> 3
            score >= targetScore * 1.5 -> 2
            score >= targetScore -> 1
            else -> 0
        }
    }
} 