//npm i @react-native-async-storage/async-storage
//lam App quan ly dat dai -> luu vao local storage
import React,{useState,useEffect,useCallback} from "react";
import { View,Text,TextInput,Button,FlatList,TouchableOpacity } from "react-native";
import { useFocusEffect } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
//Ding nghia man hinh home
const HomeScreen = ({navigation}) =>{
    const [lands,setLands]=useState([]);
    const [search,setSearch]=useState('');
    useFocusEffect(
        useCallback(()=>{
            (async () =>{
                //lay ve danh sach cac manh dat trong localStorage
                const data = await AsyncStorage.getItem('lands'); 
                setLands(data ? JSON.parse(data) : []);//cap nhat vao bien data   
            })()
        },[])
    );
    //giao dien man hinh Home
    return(
        <View style={{flex:1,padding:20}}>
            <TextInput placeholder="Tim kiem" onChangeText={setSearch}/>
            <FlatList
                data={lands.filter(l=>l.name.includes(search)||l.location.includes(search))}
                keyExtractor={item=>item.id}
                renderItem={({item})=>(
                    <TouchableOpacity onPress={()=> navigation.navigate('Detail',{land: item})}>
                        <Text>{item.name} - {item.location}</Text>
                    </TouchableOpacity>
                )}
            />
            <Button title="Them" onPress={()=> navigation.navigate('Edit')} />
        </View>
    );
};
//man hinh LandScreen
const LandScreen = ({navigation,route}) =>{
    const [land,setLand]=useState(route.params?.land ||
        {id: Date.now().toString(),name:'',location:'',price:''});
    //viet ham luu
    const saveLand = async () =>{
        const storedLands=JSON.parse(await AsyncStorage.getItem('lands')) || [];
        await AsyncStorage.setItem('lands',
            JSON.stringify(route.params?.land ? storedLands.map(l=>l.id === land.id ? 
                land: l) : [...storedLands,land]));
        navigation.goBack();
    };
    //giao dien cua phan luu
    return(
        <View style={{flex:1,padding:10}}>
            <TextInput placeholder="Ten" value={land.name} 
            onChangeText={v=>setLand({...land,name:v})}/>
            <TextInput placeholder="Vi tri" value={land.location} 
            onChangeText={v=>setLand({...land,location:v})}/>
            <TextInput placeholder="Gia" value={land.price} 
            onChangeText={v=>setLand({...land,price:v})} keyboardType="numeric"/>
            <Button title="Luu" onPress={saveLand} />
        </View>
    );
};
// detail screen
const DetailSceen = ({route,navigation}) =>{
    const {land} = route.params;
    const deleteLand = async () =>{
        const storedLand = 
        JSON.parse(await AsyncStorage.getItem('lands')) || [];
        await AsyncStorage.setItem('lands',
            JSON.stringify(storedLand.filter(l=>l.id !== land.id)));
            navigation.goBack();
    };
    //giao dien
    return(
        <View style={{flex:1,padding:20}}>
            <Text>{land.name}</Text>
            <Text>{land.location}</Text>
            <Text>{land.price}</Text>
            <Button title="Xoa" onPress={deleteLand}/>
            <Button title="Sua" onPress={()=>navigation.navigate('Edit',{land})}/>
        </View>
    );
};
//navigation
const Stack = createStackNavigator();
export default function Slot11_1(){
    return(
        <Stack.Navigator>
            <Stack.Screen name="Home" component={HomeScreen}/>
            <Stack.Screen name="Edit" component={LandScreen}/>
            <Stack.Screen name="Detail" component={DetailSceen}/>
        </Stack.Navigator>
    );
}


