import React from "react";
import { Button,ScrollView } from "react-native";
import ProductFn from "./ProductFn";
const DetailFn = ({navigation,route}) =>{
    //code
    const data1 = route.params?.data || "";//lay du lieu tu list chuyen sang
    //viet ham them vao gio hang
    const addToCart = ({d}) =>{
        navigation.navigate('CartFn',{data: d});
    };
    //layout
    return(
        <ScrollView>
            <ProductFn dataProd={data1}/>
            <Button title="Add to Cart" onPress={()=>addToCart({d:data1})}/>
        </ScrollView>
    );
}
export default DetailFn;