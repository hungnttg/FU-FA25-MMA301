//npm i @react-navigation/stack
//npm i @react-natigation/native
import React,{useState, useEffect} from "react";
import { FlatList } from "react-native";
import ProductFn from "./ProductFn";
import {useNavigation,useRoute} from "@react-navigation/native";
const ListproductFn = () =>{
    //code
    const navigation=useNavigation();
    const route = useRoute();
     const [prd,setPrd]=useState(null);
     //viet ham doc du lieu
     const getProducts = async () =>{
        const url = 'https://hungnttg.github.io/shopgiay.json';
        const response = await fetch(url,{method:'GET'});
        const responseJson = await response.json();//chuyen sang json
        //cap nhay vao brd
        setPrd(responseJson.products);
     };
     //ham ket xuat du leiu
     const renderItemFlatList = ({item}) =>{
        return(
            <ProductFn dataProd={item} handlePress={()=>viewDetail({p:item})}/>
        );
     };
     //su dung useEfetct de reload du lieu
     useEffect(()=>{
        getProducts();
        },[]);
     const viewDetail = ({p}) =>{
        navigation.navigate('DetailFn',{data: p});
     }
    //layout
    return(
        <FlatList
            data={prd}
            renderItem={renderItemFlatList}
            numColumns={3}
            removeClippedSubviews
        />
    );
}
export default ListproductFn;