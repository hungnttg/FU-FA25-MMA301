import React from "react";
import { Text,View,Image,StyleSheet,TouchableWithoutFeedback } from "react-native";
const ProductFn = ({dataProd,handlePress}) =>{
    //code
    const fun_handlePress = () =>{
        if(handlePress){
            handlePress(dataProd);
        }
    };
    //layout
    return(
        <TouchableWithoutFeedback onPress={fun_handlePress}>
            <View>
                <Image source={{uri: dataProd.search_image}} style={styles.image}/>
                <Text>{dataProd.styleid}</Text>
                <Text>{dataProd.brands_filter_facet}</Text>
                <Text>{dataProd.price}</Text>
                <Text>{dataProd.product_additional_info}</Text>
            </View>
        </TouchableWithoutFeedback>
    );
}
const styles = StyleSheet.create({
    container:{
        flex:1,
    },
    image:{
        width:200,height:200,borderWidth:1,
    }
});
export default ProductFn;