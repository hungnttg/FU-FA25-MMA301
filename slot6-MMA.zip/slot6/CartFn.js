import React,{useState} from "react";
import { View,ScrollView,Button,FlatList,Text } from "react-native";
import ProductFn from './ProductFn';
export default function CartFn({route}){
    const data = route.params?.data||"";
    const [count,setCount]=useState(1);
    const [list,setList]=useState([]);
    const addToCart=()=>setList([{data},...list]);
    return(
        <View>
            <ScrollView>
                <ProductFn dataProd={data}/>
                <Button title="+" onPress={()=>setCount(count+1)}/>
                <Text>So luong san pham: {count}</Text>
                <Button title="-" onPress={()=>setCount(count-1)}/>
                <Button title="All product" onPress={addToCart}/>
                <FlatList data={list} numColumns={2} 
                renderItem={({item})=> <ProductFn dataProd={item.data}/>} />
            </ScrollView>
        </View>
    );
}